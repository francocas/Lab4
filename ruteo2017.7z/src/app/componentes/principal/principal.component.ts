import { Component, OnInit } from '@angular/core';
import { Juego } from '../../clases/juego'

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  constructor() { this.listadoRecibido = new Array<any>() }

  ngOnInit() {
  }
  title = 'app';
  listadoRecibido : Array<any>;
 
  mostrar(juego : Juego)
  {
    this.listadoRecibido.push(juego);
    console.info("en app",this.listadoRecibido);
  }

}
