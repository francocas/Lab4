import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { AdivinaElNumeroComponent } from './componentes/adivina-el-numero/adivina-el-numero.component';
import { ListadoDeResultadosComponent } from './componentes/listado-de-resultados/listado-de-resultados.component';
import { LoginComponent } from './componentes/login/login.component';

//agrego las clases para utilizar ruteo
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './componentes/error/error.component';
import { PrincipalComponent } from './componentes/principal/principal.component';
import { AgilidadAritmeticaComponent } from './componentes/agilidad-aritmetica/agilidad-aritmetica.component';
import { MenuComponent } from './componentes/menu/menu.component';

//declaro donde quiero que se dirija
let MiRuteo = [{path:'error' , component: ErrorComponent}, 
{path:'Login' , component: LoginComponent},
{path:'adivina' , component: AdivinaElNumeroComponent},
{path:'agilidad' , component: AgilidadAritmeticaComponent},
{path:'' , component: PrincipalComponent ,pathMatch:'full'},
{path:'**' , component: ErrorComponent}]

@NgModule({
  declarations: [
    AppComponent,
    AdivinaElNumeroComponent,
    ListadoDeResultadosComponent,
    ErrorComponent,
    PrincipalComponent,
    LoginComponent,
    AgilidadAritmeticaComponent,
    MenuComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    //importo el ruteo
     RouterModule.forRoot(MiRuteo)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
